//
//  TodoItemCell.swift
//  tasklist
//
//  Created by user151724 on 02/04/19.
//  Copyright © 2019 user151724. All rights reserved.
//

import Foundation
import UIKit

class TodoItemCell: UITableViewCell {
    var isCompleted: Bool = false {
        didSet {
            guard let currentText = textLabel?.text else { return }
            
            let strikeStyle = isCompleted
                ? NSNumber(value: NSUnderlineStyle.single.rawValue)
                : NSNumber(value: 0)
            let strokeEffect: [NSAttributedString.Key : Any] = [.strikethroughStyle: strikeStyle,
                                                                .strikethroughColor: UIColor.black]
            
            textLabel?.attributedText = NSAttributedString(string: currentText,
                                                           attributes: strokeEffect)
        }
    }
}
