//
//  Todo.swift
//  tasklist
//
//  Created by user151724 on 11/04/19.
//  Copyright © 2019 user151724. All rights reserved.
//

import Foundation
struct Todo : Codable{
    var task:String
    var isCompleted:Bool = false
    var id: Int?
    
    init(task: String){
        self.task = task
        self.isCompleted = false
    }
}
