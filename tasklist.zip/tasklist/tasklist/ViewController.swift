//
//  ViewController.swift
//  tasklist
//
//  Created by user151724 on 02/04/19.
//  Copyright © 2019 user151724. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    struct Todo {
        var task: String
        var isCompleted: Bool
        
        init(task: String){
            self.task = task
            self.isCompleted = false
        }
    }
    
    var itens: [Todo] = [
        Todo(task: "Terminar exercicios de IOS"),
        Todo(task: "Trocar android por um Iphone"),
        Todo(task: "Comprar um Macbook"),
    ]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        // Do any additional setup after loading the view.
        tableView.register(TodoItemCell.self,
                           forCellReuseIdentifier: "todoItem")
    }

    @IBAction func AddItem(_ sender: Any) {
        let alert = UIAlertController(title: "Nova Tarefa", message: "Digite a nova tarefa", preferredStyle: .alert)
        alert.addTextField{(textField) in textField.placeholder = "Tarefa"}
        
        var itemAux  = self.itens
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: {(_) in
            guard let task = alert.textFields?.first?.text else {return}
            
            itemAux.insert(Todo(task: task),at: 0)
            self.itens = itemAux
            self.tableView.reloadData()
        })
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
        
    }
    
    func reloadRows(at indexPaths: [IndexPath],
                    with animation: UITableView.RowAnimation){
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "todoItem", for: indexPath) as? TodoItemCell else { fatalError() }
        
        let todo = itens[indexPath.row]
        cell.textLabel?.text = todo.task
        cell.isCompleted = todo.isCompleted
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        itens[indexPath.row].isCompleted.toggle()
        tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.left)
    }

    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        return indexPath
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let removeAction = UIContextualAction(
            style: .destructive, title: "Remover", handler: {
                (action, view, completionHandler) in
                // Remover item da lista
                self.itens.remove(at: indexPath.row)
                self.tableView.reloadData()
                completionHandler(true)
        })
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [removeAction])
        return swipeConfiguration
    }

    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let tarefa = self.itens[indexPath.row].isCompleted
        var msg = "Feito"
        if (tarefa){
            msg = "Pendente"
        }
        let RealizarTarefaAction = UIContextualAction(
            style: .normal, title: msg, handler: {
                (action, view, completionHandler) in
                if (tarefa){
                    self.itens[indexPath.row].isCompleted = false
                }
                else{
                    self.itens[indexPath.row].isCompleted.toggle()
                }
                
                tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.middle)
                self.tableView.reloadData()
                completionHandler(true)
        })
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [RealizarTarefaAction])
        return swipeConfiguration
    }
}

