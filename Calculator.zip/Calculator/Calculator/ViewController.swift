import UIKit

class ViewController: UIViewController {
    // MARK: - Outlets

    @IBOutlet private weak var digit0Button: UIButton!
    @IBOutlet private weak var digit1Button: UIButton!
    @IBOutlet private weak var digit2Button: UIButton!
    @IBOutlet private weak var digit3Button: UIButton!
    @IBOutlet private weak var digit4Button: UIButton!
    @IBOutlet private weak var digit5Button: UIButton!
    @IBOutlet private weak var digit6Button: UIButton!
    @IBOutlet private weak var digit7Button: UIButton!
    @IBOutlet private weak var digit8Button: UIButton!
    @IBOutlet private weak var digit9Button: UIButton!
    @IBOutlet private weak var cleanButton: UIButton!
    @IBOutlet private weak var sumOpButton: UIButton!
    @IBOutlet private weak var subtractOpButton: UIButton!
    @IBOutlet private weak var timesOpButton: UIButton!
    @IBOutlet private weak var divideOpButton: UIButton!
    @IBOutlet private weak var equalButton: UIButton!
    @IBOutlet private weak var resultLabel: UILabel!
    
    var cResult: String = ""
    var cNumber: String = ""
    
    // MARK: - Stored Properties

    private let calculator = Calculator()

    // MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        registerTouchEvents()
    }

    // MARK: -

    /// Registra o método que será acionado ao tocar em cada um dos eventos.
    private func registerTouchEvents() {
        let digitButtons = [digit0Button, digit9Button, digit8Button,
                            digit7Button, digit6Button, digit5Button,
                            digit4Button, digit3Button, digit2Button,
                            digit1Button]

        let operationButtons = [sumOpButton, subtractOpButton, timesOpButton, divideOpButton]

        digitButtons.forEach { $0?.addTarget(self, action: #selector(digitTap), for: .touchUpInside) }
        operationButtons.forEach { $0?.addTarget(self, action: #selector(operationTap(sender:)), for: .touchUpInside) }
        cleanButton.addTarget(self, action: #selector(clearTap), for: .touchUpInside)
        equalButton.addTarget(self, action: #selector(makeOperation), for: .touchUpInside)
    }

    /// Esse método é responsável por adicionar um dígito na calculadora
    /// - Parameter sender: Referência do botão que está executando a ação
    @objc func digitTap(sender: UIButton) {
        
        switch sender {
        case digit0Button:
            cNumber += "0"
        case digit1Button:
            cNumber += "1"
        case digit2Button:
            cNumber += "2"
        case digit3Button:
            cNumber += "3"
        case digit4Button:
            cNumber += "4"
        case digit5Button:
            cNumber += "5"
        case digit6Button:
            cNumber += "6"
        case digit7Button:
            cNumber += "7"
        case digit8Button:
            cNumber += "8"
        case digit9Button:
            cNumber += "9"
        default:
            resultLabel.text = "ERROR"
            cResult = ""
        }
        
        resultLabel.text = cNumber
        
        /*/ Se vazio então recebe primeiro número
        if cResult == "" {
            cResult = cNumber
            resultLabel.text = cNumber
        } else {
            // Se contem operador, então soma expressão
            if cResult.contains("+") || cResult.contains("-")  || cResult.contains("/") || cResult.contains("*"){
                cResult += cNumber
                resultLabel.text = cNumber
            } else {
                // Se digitou algo que deu erro então limpa o resultado.
                if resultLabel.text == "ERROR" {
                    cResult = ""
                } else {
                    // Se contem qualquer coisa sem operador e digitou um numero, então soma
                    cResult += resultLabel.text!
                }
            }
        }*/
    }

    /// Método acionado quando o botão AC é tocado.
    @objc func clearTap() {
        cNumber = ""
        resultLabel.text = "0"
        cResult = ""
    }

    /// Metódo responsável por escolhe qual a operação será realizada.
    /// - Parameter sender: Referência do botão de operação que foi tocado
    @objc func operationTap(sender: UIButton) {
        switch sender {
        case    sumOpButton:
            cResult += cNumber
            cResult += " + "
            cNumber = ""
        case    subtractOpButton:
            cResult += cNumber
            cResult += " - "
            cNumber = ""
        case   timesOpButton:
            cResult += cNumber
            cResult += " * "
            cNumber = ""
        case   divideOpButton:
            cResult += cNumber
            cResult += " / "
            cNumber = ""
        default:
            resultLabel.text = "ERROR"
            cResult = ""
        }
    }

    /// Método acionado quando o botão = é tocado.
    @objc func makeOperation() {
        cResult += cNumber
        let intDictionary = ["0": 0,"1": 1,"2": 2,"3": 3,"4": 4,"5": 5,"6": 6,"7": 7,"8": 8,"9": 9]
        let nResult = cResult.expression.expressionValue(with: intDictionary, context: nil)
        cResult = "\(nResult ?? 0)"
        resultLabel.text = cResult
        cNumber = ""        
    }
}

extension String {
    var expression: NSExpression {
        return NSExpression(format: self)
    }
}
