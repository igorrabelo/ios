//
//  ViewController.swift
//  Idade
//
//  Created by user151724 on 26/03/19.
//  Copyright © 2019 user151724. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var dDateNasc: UITextField!
    @IBOutlet weak var cResult: UILabel!
    
    @IBAction func bButCalc(_ sender: Any) {
       
        var nIdade: Int
        
        do {
            nIdade = try calcIdade(from: dDateNasc.text ?? "", dateForma: "dd/MM/yyyy")
            cResult.text = "\(nIdade) Anos!"
        } catch IdadError.TextoVazio {
            cResult.text = "Informe um data (DD/MM/AAAA)!"
        } catch IdadError.DataInvalida {
            cResult.text = "Data inválida (DD/MM/AAAA)!"
        } catch IdadError.FormatoInvalido {
            cResult.text = "Formato inválido (DD/MM/AAAA)!"
        } catch IdadError.AniverFuturo {
            cResult.text = "Prevendo o futuro!"
        } catch {
            cResult.text = "Erro inesperado!"
        }
        
    }
    
    enum IdadError: Error {
        case TextoVazio
        case FormatoInvalido
        case DataInvalida
        case AniverFuturo
        case Inexistente
    }
    
    private func calcIdade(from text: String, dateForma: String) throws -> Int {
        
        
        let dateForm = DateFormatter()
        dateForm.dateFormat = dateForma
        let now = Date()
        
        if text.isEmpty {
            throw IdadError.TextoVazio
        } else {
            if text.count != 10 {
                throw IdadError.FormatoInvalido
            } else {
                let niver = dateForm.date(from: text)
                if niver == nil {
                    throw IdadError.DataInvalida
                } else {
                    if niver! > now {
                        throw IdadError.AniverFuturo
                    } else {
                        let idade = Calendar.current.dateComponents([.year], from: niver!, to: now).year
                        if idade == nil {
                            throw IdadError.Inexistente
                        } else {
                            return idade ?? 0
                        }
                    }
                }
            }
        }
        return 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

